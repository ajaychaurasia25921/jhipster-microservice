/**
 * Service layer beans.
 */
package com.finastra.service;
