/**
 * View Models used by Spring MVC REST controllers.
 */
package com.finastra.web.rest.vm;
