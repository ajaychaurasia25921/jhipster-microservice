/**
 * JPA domain objects.
 */
package com.finastra.domain;
