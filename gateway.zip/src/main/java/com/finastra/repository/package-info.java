/**
 * Spring Data JPA repositories.
 */
package com.finastra.repository;
