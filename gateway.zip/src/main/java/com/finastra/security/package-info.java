/**
 * Spring Security configuration.
 */
package com.finastra.security;
